package com.ecommerce;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CustomConfiguration {
    @Bean
    public org.apache.catalina.startup.ClassLoaderFactory$Repository classLoaderRepository() {
        return new org.apache.catalina.startup.ClassLoaderFactory$Repository();
    }
}
