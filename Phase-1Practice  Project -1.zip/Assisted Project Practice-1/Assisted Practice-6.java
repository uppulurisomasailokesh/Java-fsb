package com.assistedpractic;
import java.util.*;
public class MapVerfication 
{
	public static void main(String[] args) 
	{
		  HashMap<Integer,String> hm=new HashMap<Integer,String>();      
	      hm.put(1,"soma");    
	      hm.put(2,"sai");    
	      hm.put(3,"lokesh");   
	       
	      System.out.println("\nThe elements of Hashmap are ");  
	      for(Map.Entry m:hm.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
	      
	     
	       
	      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
	      
	      ht.put(4,"ram");  
	      ht.put(5,"lakshma");  
	      ht.put(6,"ramana");  
	      ht.put(7,"vinaya");  

	      System.out.println("\nThe elements of HashTable are ");  
	      for(Map.Entry n:ht.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      }
	      
	      
	     
	      
	      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
	      map.put(8,"raju");    
	      map.put(9,"rajini");    
	      map.put(10,"venkat");       
	      
	      System.out.println("\nThe elements of TreeMap are ");  
	      for(Map.Entry l:map.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }    
	      
	   }
}
	