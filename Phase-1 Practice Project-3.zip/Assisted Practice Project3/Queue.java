package data_structures;

public class Queue 
{
	private int x[];
	private int front, rear;
	private int capacity;
	
	public Queue(int size)
	{
		x = new int[size];
		front = -1;
		rear = -1;
		capacity = size;
	}
	
	public boolean isEmpty()
	{
		// return front==-1;
		
		if(front==-1)
			return true;
		else
			return false;
	}
	
	public boolean isFull()
	{
		if(front==0 && rear==capacity-1)
			return true;
		else
			return false;
	}
	
	public void EnQueue(int n)
	{
		if(this.isFull())
		{
			System.out.println("Queue is Full");
			System.exit(0);
		}
		
		if(front==-1)
			front=0;
		
		x[++rear] = n;
		System.out.println("Inserted Value : " + n);
	}
	
	public int DeQueue()
	{
		if(this.isEmpty())
		{
			System.out.println("Queue is Empty");
			System.exit(0);
		}
		
		int val = x[front];
		if(front>=rear)
		{
			front = -1;
			rear = -1;
		}
		else
			front++;
		System.out.println("\nRemoved Value : " + val);
		return val;
	}
	
	public void printQueue()
	{
		if(this.isEmpty()==false)
		{
			for(int i=front;i<=rear;i++)
			{
				System.out.print(x[i] + "  ");
			}
		}
	
}

	public static void main(String[] args)
	{
		Queue  que = new Queue(5);
		
		que.EnQueue(10);
		que.EnQueue(20);
		que.EnQueue(30);
		que.EnQueue(40);
		que.EnQueue(50);
		//que.EnQueue(60);
		que.printQueue();
		
		que.DeQueue();
		que.printQueue();		
		que.DeQueue();
		que.printQueue();		
		que.DeQueue();
		que.printQueue();
		que.DeQueue();
		que.printQueue();
		que.DeQueue();
		que.printQueue();

	}				
}
