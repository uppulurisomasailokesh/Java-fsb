package data_structures;

import java.util.*;

public class LongestIncreasingSubsequence 
{
	
	public static void main(String[] args) 
	{
		
		Scanner sc = new Scanner(System.in);
	        
	    System.out.print("Enter the number of elements: ");
	        
	    int n = sc.nextInt();
	        
	    int[] nums = new int[n];
	        
	    System.out.println("Enter the elements: ");
	        
	    for (int i = 0; i < n; i++)
	    	
	        {
	            nums[i] = sc.nextInt();
	        }
	        
	        sc.close();
	        
	        int[] longestSubsequence = LongestIncreasingSubsequence(nums);

	        System.out.println("Longest Increasing Subsequence:");
	        for (int num : longestSubsequence)
	        {
	            System.out.print(num + " ");
	        }
	    }

	    public static int[] LongestIncreasingSubsequence(int[] nums) 
	    {
	        int n = nums.length;
	        int[] dp = new int[n];
	    
	        for (int i = 0; i < n; i++)
	        {
	            dp[i] = 1;
	        }
	    
	        int maxLength = 1;
	        int endIndex = 0;
	    
	        for (int i = 1; i < n; i++) 
	        {
	            for (int j = 0; j < i; j++) 
	            {
	                if (nums[i] > nums[j] && dp[i] < dp[j] + 1) 
	                {
	                    dp[i] = dp[j] + 1;
	                    if (dp[i] > maxLength)
	                    {
	                        maxLength = dp[i];
	                        endIndex = i;
	                    }
	                }
	            }
	        }	    
	        int[] longestSubsequence = new int[maxLength];
	        longestSubsequence[maxLength - 1] = nums[endIndex];
	    
	        for (int i = endIndex - 1; i >= 0; i--) 
	        {
	            if (nums[i] < nums[endIndex] && dp[i] == dp[endIndex] - 1) 
	            {
	                maxLength--;
	                longestSubsequence[maxLength - 1] = nums[i];
	                endIndex = i;
	            }
	        }	    
	        return longestSubsequence;
	    }
}
