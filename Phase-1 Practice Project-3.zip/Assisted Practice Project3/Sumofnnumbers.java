package data_structures;

import java.util.Scanner;

public class Sumofnnumbers 
{
    public static int calculateSum(int[] arr, int L, int R)
    {
        int sum = 0;

        if (L < 0 || R >= arr.length || L > R)
        {
            throw new IllegalArgumentException("Invalid range");
        }

        for (int i = L; i <= R; i++) 
        {
            sum += arr[i];
        }

        return sum;
    }

	public static void main(String[] args) 
	{
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements (n): ");
        int n = scanner.nextInt();

        int[] arr = new int[n];

        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) 
        {
            arr[i] = scanner.nextInt();
        }

        System.out.print("Enter the value of L: ");
        int L = scanner.nextInt();

        System.out.print("Enter the value of R: ");
        int R = scanner.nextInt();

        scanner.close();

        int sumInRange = calculateSum(arr, L, R);

        System.out.println("The sum of elements in the range of L and R is: " + sumInRange);
    }

}


