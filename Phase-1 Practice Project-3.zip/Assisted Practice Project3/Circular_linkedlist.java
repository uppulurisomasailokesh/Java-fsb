package data_structures;

public class Circular_linkedlist 
{
	class Node
	{
		int data;
		Node next;
		
		public Node(int data)
		{
			this.data = data;	
		}
	}
		public Node head = null, tail =null;
		
		public void addNode(int data)
		{
			Node newNode = new Node(data);
			if(head==null)
			{
				head = newNode;
				tail = newNode;
				newNode.next = head;
			}
			else
			{
				tail.next = newNode;
				tail = newNode;
				tail.next = head;
			}
		}	
		
		public void ShowValues()
		{
			Node current = head;
			if(head==null)
			{
				System.out.println("List is Empty");
				return;
			}
			
			do
			{
				System.out.print(current.data + "  ");
				current = current.next;
			}
			while(current!=head);
		}
	public static void main(String[] args)
	{
		Circular_linkedlist  cll = new Circular_linkedlist();
		
		cll.addNode(100);
		cll.addNode(200);
		cll.addNode(300);
		cll.addNode(400);
		cll.addNode(500);
		
		cll.ShowValues();
	}
		

}
