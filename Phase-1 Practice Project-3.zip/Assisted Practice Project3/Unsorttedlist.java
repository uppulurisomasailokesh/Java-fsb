package data_structures;

import java.util.Arrays;

public class Unsorttedlist
{
    public static int findFourthSmallest(int[] arr)
    {
        if (arr.length < 4)
        {
            throw new IllegalArgumentException("List should contain at least four elements");
        }

        Arrays.sort(arr);
        return arr[3];
    }

	public static void main(String[] args)
	{
		int[] list = {12, 3, 1, 5, 8, 10, 20};
		
        int fourthSmallest = findFourthSmallest(list);
        
        System.out.println("The fourth smallest element is: " + fourthSmallest);
		

	}

}
