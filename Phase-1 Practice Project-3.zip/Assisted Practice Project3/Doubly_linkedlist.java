package data_structures;

public class Doubly_linkedlist 
{
	class Node 
	{
		int data;
		Node prvs;
		Node next;
		
		public  Node(int data)
		{
			this.data = data;
			this.prvs = null;
			this.next = null;
		}
	}
	
	public Node head = null, tail = null;
	
	public void addNode(int data)
	{
		Node newNode = new Node(data);
		
		if(head==null)
		{
			head = newNode;
			tail = newNode;
			head.prvs = null;
			tail.next = null;
		}
		else
		{
			tail.next = newNode;
			newNode.prvs = tail;
			tail = newNode;  // data
			tail.next = null;
		}
	}
	
	public void ShowValuesForward()
	{
		Node current = head;
		if(head==null)
		{
			System.out.println("List is Empty");
			return;
		}
		while(current!=null)
		{
			System.out.print(current.data + "   ");
			current = current.next;
		}
		
	}

	public void ShowValuesBackward()
	{
		Node current = tail;
		if(head==null)
		{
			System.out.println("List is Empty");
			return;
		}
		while(current!=null)
		{
			System.out.print(current.data + "   ");
			current = current.prvs;
		}
		
	}

	public static void main(String[] args) 
	{
		Doubly_linkedlist dll = new Doubly_linkedlist();
		dll.addNode(100);
		dll.addNode(200);
		dll.addNode(300);
		dll.addNode(400);
		dll.addNode(500);
		System.out.println("Forward Feature");
		dll.ShowValuesForward();
		
		System.out.println("\nBackward Feature");
		dll.ShowValuesBackward();
		

	}

}
